
// 这是es6的语法，webpack里，需要走打包编译 才能调试
// vite立不需要，直接浏览器支持es6

export function sayProblem(){
  console.log('贼个问题')
}

 
// const Markdown = require('./lib')
import Markdown from './lib/index.js';

const md = new Markdown();

const mdString = [
`# title
### title3
###### sixsixsix`,
]

const ast = md.parse( mdString[0] );
// console.dir(ast, {depth: 10});

const html = md.render(ast);
console.log(html)

document.body.appendChild(html);

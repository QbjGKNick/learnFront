const Markdown = require('./lib')

const md = new Markdown();

const mdString = [
`# title
### title3`,
]

const ast = md.parse( mdString[0] );
// console.dir(ast, {depth: 10});

const html = md.render(ast);
console.log(html)
